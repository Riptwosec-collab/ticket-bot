import { NextResponse } from 'next/server';

export async function POST() {
  return NextResponse.json({
    success: false,
    message: 'การสั่งหยุดโปรเซสยังไม่รองรับบนโฮสติ้งแบบ serverless',
  }, { status: 501 });
}
